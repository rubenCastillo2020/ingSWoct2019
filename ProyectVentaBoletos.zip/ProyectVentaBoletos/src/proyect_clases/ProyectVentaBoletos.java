package proyect_clases;

import proyect_gui.GUI_Principal;
import proyect_gui.GUIi_AccesoSistema;


public class ProyectVentaBoletos {
   
    public static void main(String[] args) {
    
    GUIi_AccesoSistema f = new GUIi_AccesoSistema();
    f.setVisible (true); 
       }
}
